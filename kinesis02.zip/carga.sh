#!/bin/bash

# Define a variável para o número de paralelismos
num_requests=30

# Função para enviar o registro ao Kinesis
send_kinesis_record() {
    # Envia a requisição para o Kinesis e redireciona a saída para /dev/null
    aws kinesis put-record --stream-name poc --partition-key 1 --data "HelloKinesis" --profile sandbox > /dev/null 2>&1 &
}

# Loop para enviar os registros em paralelo
for i in $(seq 1 $num_requests); do
    send_kinesis_record
done

# O terminal será liberado imediatamente após este comando
echo "As requisições foram iniciadas em segundo plano."

